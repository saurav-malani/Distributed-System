import java.net.*;
import java.io.*;

class FileTransfer implements Runnable 
{
	Thread t;
	FileTransfer() 
	{
		t = new Thread(this);
		t.start();
	}
	
	public void run() 
	{
		try {

			ServerSocket serverSocket = new ServerSocket(15123);
		      Socket socket = serverSocket.accept();
		      System.out.println("Accepted connection : " + socket);
		      File transferFile = new File ("Chapter13.pdf");
		      byte [] bytearray  = new byte [(int)transferFile.length()];
		      FileInputStream fin = new FileInputStream(transferFile);
		      BufferedInputStream bin = new BufferedInputStream(fin);
		      bin.read(bytearray,0,bytearray.length);
		      OutputStream os = socket.getOutputStream();
		      System.out.println("Sending Files...");
		      os.write(bytearray,0,bytearray.length);
		      os.flush();
		      socket.close();
		      System.out.println("File transfer complete");
		  }
		  catch(Exception e) {

		  }
	}
}

class AliceClass implements Runnable
{
	Thread t;
	Socket client;
	AliceClass(Socket client)
	{
		this.client=client;
		t=new Thread(this);
		t.start();	
	}
	public void run()
	{
		try
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(client.getInputStream()));
			while(true)
			{
				String st1=br.readLine();
				System.out.println("Bob: "+st1);
                                System.out.print(">>");
			}
		}
		catch(IOException e)
		{
			System.out.println(e);

		}	
	}
}

class Alice
{
public static void main(String args[]) throws IOException 
{
	FileTransfer ft = new FileTransfer();

	ServerSocket server=new ServerSocket(1301);
	System.out.println("waiting for request from peer.....");
	Socket client=server.accept();
	AliceClass s=new AliceClass(client);
	System.out.println("request accepted");
	System.out.print(">>");
	BufferedReader br2=new BufferedReader(new InputStreamReader(System.in));
	PrintStream ps2=new PrintStream(client.getOutputStream());
   	while(true)
	{
		String st=br2.readLine();
		if(s.equals("Sending Chapter13.pdf TCP"))
		{
			int filesize=1022386; 
		    int bytesRead;
		    int currentTot = 0;
		    Socket socket = new Socket("127.0.0.1",15123);
		    byte [] bytearray  = new byte [filesize];
		    InputStream is = socket.getInputStream();
		    FileOutputStream fos = new FileOutputStream("Chapter13.pdf");
		    BufferedOutputStream bos = new BufferedOutputStream(fos);
		    bytesRead = is.read(bytearray,0,bytearray.length);
		    currentTot = bytesRead;

		    do {
		       bytesRead =
		          is.read(bytearray, currentTot, (bytearray.length-currentTot));
		       if(bytesRead >= 0) 
		       	{
	     
	       		currentTot += bytesRead;
	       		int percent=((currentTot*100)/bytearray.length);
	       		System.out.println("Receiving Chapter13.pdf      [===>]"+percent+"%");
	    	//	System.out.println(currentTot);
	    	
	    		}
			       	

		    } while(bytesRead > -1);

		    bos.write(bytearray, 0 , currentTot);
		    bos.flush();
		    bos.close();
		    socket.close();
		}
		else
			ps2.println(s);
	}
	}   
}
