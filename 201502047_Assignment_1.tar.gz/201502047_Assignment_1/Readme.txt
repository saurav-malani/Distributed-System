Both alice and bob are in different folder, so that we can exactly see that the file is being transfered.
steps:
1. compile Alice using "javac Alice.java"
2. in other teminal similarly compile Bob.
3. now first run Alice
4. then bob
5. then use send Sending Chapter13.pdf TCP to send it.

