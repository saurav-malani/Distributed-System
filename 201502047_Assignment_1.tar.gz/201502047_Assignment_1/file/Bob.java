import java.net.*;
import java.io.*;

class FileTransfer implements Runnable 
{
	Thread t;
	FileTransfer() 
	{
		t = new Thread(this);
		t.start();
	}

	public void run() 
	{
		try {
			ServerSocket serverSocket = new ServerSocket(15124);
		      Socket socket = serverSocket.accept();
		      System.out.println("Accepted connection : " + socket);
		      File transferFile = new File ("Chapter13.pdf");
		      byte [] bytearray  = new byte [(int)transferFile.length()];
		      FileInputStream fin = new FileInputStream(transferFile);
		      BufferedInputStream bin = new BufferedInputStream(fin);
		      bin.read(bytearray,0,bytearray.length);
		      OutputStream os = socket.getOutputStream();
		      System.out.println("Sending Files...");
		      os.write(bytearray,0,bytearray.length);
		      os.flush();
		      socket.close();
		      System.out.println("File transfer complete");
		  }
		  catch(Exception e) {

		  }
	}
}

class BobClass implements Runnable
{
	Thread t;
	Socket client;
	BobClass(Socket client)
	{
		this.client=client;
		t=new Thread(this);
		t.start();
		
		}
	public void run()
	{
		try{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(client.getInputStream()));
		while(true)
		{	
			String st1=br.readLine();
			System.out.println("Alice: "+st1);
                        System.out.print(">>");
            if(st1.equals("Sending Chapter13.pdf TCP") )
            {

            }
            if(st1.equals("Sending Chapter13.pdf UDP"))
            {


            	
            }
		}
			
		}
		catch(IOException e)
		{
			System.out.println(e);
		
		}	
	} 
}

class Bob
{
public static void main(String args[]) throws IOException 
{
	try{
		FileTransfer ft = new FileTransfer();

		System.out.println("sending request to peer....");
		Socket client=new Socket("127.0.0.1",1301);
		System.out.println("successfully conneted");
		System.out.print(">>");
		BobClass c=new BobClass(client);
	
		BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
		PrintStream ps=new PrintStream(client.getOutputStream());
		while(true)
		{
			String s=br1.readLine();
			if(s.equals("Sending Chapter13.pdf TCP"))
			{
				int filesize=1022386; 
			    int bytesRead;
			    int currentTot = 0;
			    Socket socket = new Socket("127.0.0.1",15123);
			    byte [] bytearray  = new byte [filesize];
			    InputStream is = socket.getInputStream();
			    FileOutputStream fos = new FileOutputStream("Chapter13.pdf");
			    BufferedOutputStream bos = new BufferedOutputStream(fos);
			    bytesRead = is.read(bytearray,0,bytearray.length);
			    currentTot = bytesRead;

			    do {
			       bytesRead =
			          is.read(bytearray, currentTot, (bytearray.length-currentTot));
			       if(bytesRead >= 0) 
				{
	     
	       		currentTot += bytesRead;
	       		int percent=((currentTot*100)/bytearray.length);
	       		System.out.println("Receiving Chapter13.pdf [===>]"+percent+"%");
	    	//	System.out.println(currentTot);
	    	
	    		}
			       	
			    } while(bytesRead > -1);

			    bos.write(bytearray, 0 , currentTot);
			    bos.flush();
			    bos.close();
			    socket.close();
			}
			else
				ps.println(s);
		}
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
