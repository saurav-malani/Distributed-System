from numpy import genfromtxt
import numpy as np
from random import randint
import PIL.Image
from cStringIO import StringIO
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import IPython.display
import matplotlib.image as mpimg


def showarray(a, fmt='png'):
	a = np.uint8(a);
	f = StringIO();
	PIL.Image.fromarray(a).save(f, fmt);
	IPython.display.display(IPython.display.Image(data=f.getvalue()));


if __name__ == '__main__':

	train_data = genfromtxt('notMNIST_train_data.csv', delimiter=',');
	train_labels = genfromtxt('notMNIST_train_labels.csv', delimiter=',');
	test_data = genfromtxt('notMNIST_test_data.csv', delimiter=',');
	test_labels = genfromtxt('notMNIST_test_labels.csv', delimiter=',');

	classifier1 = LogisticRegression(C=1000, penalty='l1');
	classifier1.fit(train_data, train_labels);

	pred = classifier1.predict(test_data);
	"""
	w1 = np.asarray(classifier1.coef_);
	w1 = np.reshape(w1, (28, 28));

	imgplot1 = plt.imshow(w1, cmap='gray', interpolation='nearest');
	plt.show();

	classifier2 = LogisticRegression(C=100000, penalty='l2');
	classifier2.fit(train_data, train_labels);

	pred = classifier2.predict(test_data);
	w2 = np.asarray(classifier2.coef_);
	w2 = np.reshape(w2, (28, 28));

	imgplot2 = plt.imshow(w2, cmap='gray', interpolation='nearest');
	plt.show(); 
	"""
	score = accuracy_score(pred, test_labels);
	print "Accuracy score : %f" % score;