
import numpy as np
import os, sys, csv

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score

traindir = sys.argv[1]
testdir = sys.argv[2]
x=np.genfromtxt(traindir,delimiter=",",dtype=int)
test=np.genfromtxt(testdir,delimiter=",",dtype=int)

train_label=np.copy(x[:,11])
train_data=np.copy(x[:,0:11])
#test_label=np.copy(test[:,11])
#test_data=np.copy(test[:,0:11])

clf = LogisticRegression(penalty="l2", C=1000000);
clf.fit(train_data, train_label);
	#clf = linear_model.Lasso(alpha = 0.1)
	#clf.fit([[0, 0], [1, 1]], [0, 1])
pred = clf.predict(test);

for i in pred:
	print i;