'''
import numpy as np
import os, sys, csv

from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score

def get_input_data(filename, is_test):
	data = [];
	labels = [];

	file = open(filename);
	file = csv.reader(file);

	for row in file:
		finx = np.zeros(12, dtype=float);

		for (i, item) in enumerate(row):
			if i != len(row)-1:
				finx[i] = float(item);

		data.append(finx);
		if is_test == False:
			labels.append(int(row[11]));

	return (np.asarray(data), np.asarray(labels));


if __name__ == '__main__':

	train_file = sys.argv[1];
	test_file = sys.argv[2];

	train_data, train_labels = get_input_data(train_file, False);
	test_data, test_labels = get_input_data(test_file, False);

	classifier = SGDClassifier(loss='log', penalty='elasticnet', l1_ratio=0.15, alpha=0.001);
	classifier.fit(train_data, train_labels);

	pred = classifier.predict(test_data);

	for item in pred:
		print item;
	#score = accuracy_score(test_labels, pred);

	#print "Accuracy score : %.4f" % score;
'''

import numpy as np
import os, sys, csv

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score

traindir = sys.argv[1]
testdir = sys.argv[2]
x=np.genfromtxt(traindir,delimiter=",",dtype=int)
test=np.genfromtxt(testdir,delimiter=",",dtype=int)

train_label=np.copy(x[:,11])
train_data=np.copy(x[:,0:11])
#test_label=np.copy(test[:,11])
#test_data=np.copy(test[:,0:11])

classifier = SGDClassifier(loss='log', penalty='elasticnet', l1_ratio=0.15, alpha=0.001);
classifier.fit(train_data, train_label);

pred = classifier.predict(test);

for item in pred:
	print item;
