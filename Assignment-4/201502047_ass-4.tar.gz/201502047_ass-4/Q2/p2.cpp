#include <iostream>
#include <algorithm>
#include <mpi.h>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
int main(int argc, char **argv)
{
	MPI_Init(NULL, NULL);   //initilization of MPI
	int world_rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
	int world_size;
	MPI_Comm_size(MPI_COMM_WORLD, &world_size);
	if(world_rank==0)
	{
		int n,m,t;
		vector<vector<int> > matrix;
		t=*(argv[2]) - '0';
		//char filename=argv[1];
		//m=matrix[0].size();
		//n=matrix.size();
		string line;
		ifstream f;
		f.open(argv[1]);

		while(getline(f, line))
		{
			vector<int> temp;
			for(int i=0;i<line.length();i++)
				temp.push_back(line[i] - '0');
			matrix.push_back(temp);
		}
		f.close();
		m=matrix[0].size();
		n=matrix.size();
		int arr[n][m]={0};
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
				arr[i][j]=matrix[i][j];
		}
		// cin>>n>>m>>t;
		// int arr[n][m];
		// for(int i=0;i<n;i++)
		// {
		// 	for(int j=0;j<m;j++)
		// 	{
		// 		cin>>arr[i][j];
		// //		buffer[i][j]=arr[i][j];
		// 	}
		// }
		


		int array_size=(m*n);
		int send_tag[world_size]={0},recv_tag=0;
		for(int i=0;i<t;i++)
		{
			//MPI_Send(&t,1, MPI_INT, j, send_tag[1]++, MPI_COMM_WORLD);
			for(int j=1;j<world_size;j++)
			{
				
				MPI_Send(&m,1, MPI_INT, j, send_tag[j]++, MPI_COMM_WORLD);
				MPI_Send(&n,1, MPI_INT, j, send_tag[j]++, MPI_COMM_WORLD);

			//	int ind=((i-1)*(n))/(world_size-1);
				MPI_Send(arr,array_size, MPI_INT, j, send_tag[j]++, MPI_COMM_WORLD);

			//int ind=((i-1)*(n))/(world_size-1);
			//MPI_Send(&arr[ind],array_size, MPI_INT, i, 0, MPI_COMM_WORLD);
			// MPI_Recv(&myarr, (n/world_size-1), MPI_INT, 0, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			}
			//for(int i=1;i<world_size;i++)
			//{
				//MPI_Send(&m,1, MPI_INT, i, 0, MPI_COMM_WORLD);
				//MPI_Send(&n,1, MPI_INT, i, 0, MPI_COMM_WORLD);

				//int ind=((i-1)*(n))/(world_size-1);
			MPI_Recv(arr, array_size, MPI_INT, 1,recv_tag++, MPI_COMM_WORLD,MPI_STATUS_IGNORE);	
			cout<<endl;
			// cout<<"n="<<n<<endl;
			// cout<<"m="<<m<<endl;
			for(int l=0;l<n;l++)
			{
				for(int k=0;k<m;k++)
				{
					if(arr[l][k]==1)
					cout<<"\u25A0 ";
					else
						cout<<"\u25A1 ";
				}
				cout<<endl;
			}
			//int ind=((i-1)*(n))/(world_size-1);
			//MPI_Send(&arr[ind],array_size, MPI_INT, i, 0, MPI_COMM_WORLD);
			// MPI_Recv(&myarr, (n/world_size-1), MPI_INT, 0, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			//}
			 //cout<<"t"<<i<<endl;

			

		}
		exit(0);
		MPI_Finalize(); 
	}
	else
	{
		int send_tag=0;
		int recv_tag=0;
		//int t;
		//MPI_Recv(&t, 1, MPI_INT, 0, recv_tag++, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		//int cc=0;
		while(true) {
			int array_size,m,n;
			MPI_Recv(&m, 1, MPI_INT, 0, recv_tag++, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			MPI_Recv(&n, 1, MPI_INT, 0, recv_tag++, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			array_size = m*n;
			int array[n][m];

			MPI_Recv(array, array_size, MPI_INT, 0, recv_tag++, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			int buffer[n][m];
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<m;j++)
				{
		 //		cin>>arr[i][j];
					buffer[i][j]=array[i][j];
				}
			}
		//int k;
		// cout<<"no c"<<endl;
		// for(int l=0;l<n;l++)
		// 	 {
		// 	 	for(int k=0;k<m;k++)
		// 	 	{
		// 	 		cout<<array[l][k]<<" ";
		// 	 	}
		// 	 	cout<<endl;
		// 	 }
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<m;j++)
				{
					int xstart,xend,ystart,yend;
					if(i-1>=0)
						xstart=i-1;
					else
						xstart=i;
					if(i+1<=n-1)
						xend=i+1;
					else
						xend=i;
					if(j-1>=0)
						ystart=j-1;
					else
						ystart=j;
					if(j+1<=m-1)
						yend=j+1;
					else
						yend=j;
					int count=0;
				//		cout<<xstart<<" "<<xend<<endl;
				//		cout<<ystart<<" "<<yend<<endl;
						//cout<<endl;
					for(int p=xstart;p<=xend;p++)
					{
						for(int q=ystart;q<=yend;q++)
						{
							if(array[p][q]==1)
								count++;

					//	cout<<xstart<<" "<<ystart<<" "<<count<<endl;
						}
					}
				//cout<<count<<endl;
				//cout<<endl;

					if(array[i][j]==1)
					{
						count--;
						if((count<2)||(count>3))
							buffer[i][j]=0;

					}
					if(array[i][j]==0)
					{
						if(count==3)
							buffer[i][j]=1;
					}

				}
			}
		//cout<<"party++"<<endl;
		/*for(int l=0;l<n;l++)
		{
			for(int k=0;k<m;k++)
			{
				cout<<array[l][k]<<" ";
			}
			cout<<endl;
		}*/

		//cout<<"no c"<<endl;


		//cout<<world_rank<<endl;
			if(world_rank==1)
			{

				MPI_Send(buffer,array_size, MPI_INT, 0, send_tag++, MPI_COMM_WORLD);
			}
		}
	}
	
	return 0;
}