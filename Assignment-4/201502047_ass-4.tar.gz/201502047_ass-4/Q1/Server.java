import java.util.*;
import java.io.*;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.ParseException;
import org.json.simple.parser.JSONParser;
import java.util.concurrent.ThreadLocalRandom;
import java.text.SimpleDateFormat;
import java.time.*;

class Server implements ServerInterface {

	Server() {

	}

	public void ReceiveJson(JSONArray data) throws RemoteException {
		String filename = "output_json.txt";

		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			fw = new FileWriter(filename);
			bw = new BufferedWriter(fw);

			for(int i=0;i<data.size();i++)
			{
				JSONObject obj = (JSONObject) data.get(i);
				JSONArray courseMarks = (JSONArray) obj.get("CourseMarks");

				String name = (String) obj.get("Name");
				String rollNumber = (String) obj.get("RollNo");
				
				bw.write(name + "," + rollNumber + ":");

				for(int j=0;j<courseMarks.size();j++)
				{
					JSONObject courseObj = (JSONObject) courseMarks.get(j);

					String courseScore = (String) courseObj.get("CourseScore");
					String courseName = (String) courseObj.get("CourseName");

					if(j == courseMarks.size()-1)
						bw.write(courseName + "," + courseScore);
					else
						bw.write(courseName + "," + courseScore + ":");
				}

				bw.newLine();
			}
			bw.close();

		}
		catch(Exception e) {
			System.out.println("Server file create error");
			return;
		}

		return;
	}
	public int primality(int encNum) throws RemoteException
	{
		int num=encNum ^ this.enckey;
		int n=(int)Math.sqrt((double)num);
		int flag=0;
		for(int i=2;i<=n;i++)
		{
			if(num%i==0)
			{
				flag=1;
				break;
			}

		}
		if(flag==0)
			return 1;
		else 
			return 0;


	}
	public int palindrome(byte[] encStr) throws RemoteException
	{
		byte[] temp=Arrays.copyOf(encStr,encStr.length);
		for(int i=0;i<encStr.length;++i) 
		{
			temp[i] = (byte) (encStr[i] ^ this.enckey);
		}
		string finalString="";
		try{
			s=new String(temp);

		}
		catch (Exceptiton e){
			e.printStackTrace();
		}
		String reverse = new StringBuffer(s).reverse().toString();

    // check whether the string is palindrome or not
		if (s.equals(reverse))
			return 1;
      //System.out.println("Yes");

		else
			return 0;
      //System.out.println("No");

	}
	public  int fibo(int encNum) throws RemoteException
	{
		int n=encNum^this.enckey;
		if (n == 1)
			return 0;
		if (n == 2)
			return 1;
		int i;
		else
		{	
			int n1=0;
			int n2=1;

			for(i=2;i<=n;i++)
			{	
				int ans=n1+n2;
				n1=n2;
				n2=ans;

			}
			return ans;



		}
	}
	public byte[] caseconverter(byte[] encStr) throws RemoteException
	{
		byte[] temp=Arrays.copyOf(encStr,encStr.length);
		for(int i=0;i<encStr.length;++i) 
		{
			temp[i] = (byte) (encStr[i] ^ this.enckey);
		}
		string finalString="";
		try{
			originalStr=new String(temp);

		}
		catch (Exceptiton e){
			e.printStackTrace();
		}

		char[] chars = originalStr.toCharArray();
		for (int i = 0; i < chars.length; i++)
		{
			char c = chars[i];
			if (Character.isUpperCase(c))
			{
				chars[i] = Character.toLowerCase(c);
			}
			else if (Character.isLowerCase(c))
			{
				chars[i] = Character.toUpperCase(c);
			}
		}
		byte[] byteconvert=chars.getbyte();
		for(int i=0;i<byteconvert.length;++i)
		{
			encFinal[i] = (byte) (encFinal[i] ^ this.encKey);
		}
		return new encFinal;
	}


	public void ReceiveProtoBuf(byte[] serialized) throws RemoteException {
		String filename = "output_protobuf.txt";

		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			fw = new FileWriter(filename);
			bw = new BufferedWriter(fw);

			ByteArrayInputStream bs = new ByteArrayInputStream(serialized);
			ResultProto.Result res = ResultProto.Result.newBuilder().mergeFrom(bs).build();

			int count = res.getStudentCount();
			for(int i=0;i<count;i++)
			{
				ResultProto.Student stu = res.getStudent(i);

				String name = stu.getName();
				int rollNumber = stu.getRollNum();
				bw.write(name + "," + rollNumber + ":");

				int courseCount = stu.getMarksCount();
				for(int j=0;j<courseCount;j++)
				{
					ResultProto.CourseMarks courseMarks = stu.getMarks(j);

					String courseName = courseMarks.getName();
					int score = courseMarks.getScore();

					if(j == courseCount-1)
						bw.write(courseName + "," + score);
					else
						bw.write(courseName + "," + score + ":");

				}

				bw.newLine();
			}

			bw.close();
		}
		catch(Exception e) {
			System.out.println("Server file create error");
			return;
		}

		return;
	}

	public static void main(String args[]) {
		if (System.getSecurityManager() == null) {
			System.setSecurityManager(new SecurityManager());
		}

		try {
			Registry regServer = LocateRegistry.createRegistry(1099);
			Server atmServer = new Server();
			String objName = "ServerInterface";

			ServerInterface serverStub = (ServerInterface) UnicastRemoteObject.exportObject(atmServer, 0);
			Registry reg = LocateRegistry.getRegistry();
			reg.rebind(objName, serverStub);
		}
		catch (Exception e) {
			System.out.println("Server creation error");
			e.printStackTrace();
		}
	}
}