import java.util.*;
import java.io.*;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.ParseException;
import org.json.simple.parser.JSONParser;
import java.util.concurrent.ThreadLocalRandom;
import java.text.SimpleDateFormat;
import java.time.*;

import java.rmi.*;

public interface ServerInterface extends Remote {

	public void ReceiveJson(JSONArray data) throws RemoteException;
	public void ReceiveProtoBuf(byte[] serialized) throws RemoteException;
}