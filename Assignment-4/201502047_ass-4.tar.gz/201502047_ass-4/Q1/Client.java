import java.util.*;
import java.io.*;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.ParseException;
import org.json.simple.parser.JSONParser;
import java.util.concurrent.ThreadLocalRandom;
import java.text.SimpleDateFormat;
import java.time.*;

public class Client {

	Client() { }

	public void protobuf() {
		ResultProto.Result.Builder res = ResultProto.Result.newBuilder();
		String filename = "input.txt";
		String hostname = "localhost";
		String line = null;

		try {
			Registry reg = LocateRegistry.getRegistry(hostname);
			ServerInterface clientStub = (ServerInterface) reg.lookup("ServerInterface");

			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);

			while((line = br.readLine()) != null) 
			{
				String[] dataParts = line.split(":");

				String[] studentInfo = dataParts[0].split(",");
				String name = studentInfo[0];
				String rollNumber = studentInfo[1];

				ResultProto.Student.Builder student = ResultProto.Student.newBuilder();
				student.setName(name);
				student.setRollNum(Integer.parseInt(rollNumber));

				for(int i=1;i<dataParts.length;i++)
				{
					ResultProto.CourseMarks.Builder courseMarks = ResultProto.CourseMarks.newBuilder();
					String[] courseMarksInfo = dataParts[i].split(",");

					courseMarks.setName(courseMarksInfo[0]);
					courseMarks.setScore(Integer.parseInt(courseMarksInfo[1]));

					student.addMarks(courseMarks);
				}

				res.addStudent(student);
			}

			ResultProto.Result finalRes = res.build();

			ByteArrayOutputStream bs = new ByteArrayOutputStream();
			finalRes.writeTo(bs);
			byte[] tp = bs.toByteArray();

			clientStub.ReceiveProtoBuf(tp);
			br.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("ProtoBuf error");
			return;
		}
	}
	public  int fibo(int encNum) throws RemoteException
	{
		int n=encNum^this.enckey;
		if (n == 1)
			return 0;
		if (n == 2)
			return 1;
		int i;
		else
		{	
			int n1=0;
			int n2=1;

			for(i=2;i<=n;i++)
			{	
				int ans=n1+n2;
				n1=n2;
				n2=ans;

			}
			return ans;



		}
	}
	public byte[] caseconverter(byte[] encStr) throws RemoteException
	{
		byte[] temp=Arrays.copyOf(encStr,encStr.length);
		for(int i=0;i<encStr.length;++i) 
		{
			temp[i] = (byte) (encStr[i] ^ this.enckey);
		}
		string finalString="";
		try{
			originalStr=new String(temp);

		}
		catch (Exceptiton e){
			e.printStackTrace();
		}

		char[] chars = originalStr.toCharArray();
		for (int i = 0; i < chars.length; i++)
		{
			char c = chars[i];
			if (Character.isUpperCase(c))
			{
				chars[i] = Character.toLowerCase(c);
			}
			else if (Character.isLowerCase(c))
			{
				chars[i] = Character.toUpperCase(c);
			}
		}
		byte[] byteconvert=chars.getbyte();
		for(int i=0;i<byteconvert.length;++i)
		{
			encFinal[i] = (byte) (encFinal[i] ^ this.encKey);
		}
		return new encFinal;
	}

	public void json() {
		String filename = "input.txt";
		String hostname = "localhost";
		String line = null;

		JSONArray data = new JSONArray();
		try {
			Registry reg = LocateRegistry.getRegistry(hostname);
			ServerInterface clientStub = (ServerInterface) reg.lookup("ServerInterface");

			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);

			while((line = br.readLine()) != null) 
			{
				String[] dataParts = line.split(":");

				String[] studentInfo = dataParts[0].split(",");
				String name = studentInfo[0];
				String rollNumber = studentInfo[1];

				JSONObject obj = new JSONObject();
				obj.put("Name", name);
				obj.put("RollNo", rollNumber);

				JSONArray courseMarks = new JSONArray();
				for(int i=1;i<dataParts.length;i++)
				{
					String[] courseMarksInfo = dataParts[i].split(",");

					JSONObject courseMarksObj = new JSONObject();
					courseMarksObj.put("CourseScore", courseMarksInfo[1]);
					courseMarksObj.put("CourseName", courseMarksInfo[0]);

					courseMarks.add(courseMarksObj);
				}

				obj.put("CourseMarks", courseMarks);
				data.add(obj);
			}

			clientStub.ReceiveJson(data);
			br.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("Error reading file");
			return;
		}
	}
	public int primality(int encNum) throws RemoteException
	{
		int num=encNum ^ this.enckey;
		int n=(int)Math.sqrt((double)num);
		int flag=0;
		for(int i=2;i<=n;i++)
		{
			if(num%i==0)
			{
				flag=1;
				break;
			}

		}
		if(flag==0)
			return 1;
		else 
			return 0;


	}
	public int palindrome(byte[] encStr) throws RemoteException
	{
		byte[] temp=Arrays.copyOf(encStr,encStr.length);
		for(int i=0;i<encStr.length;++i) 
		{
			temp[i] = (byte) (encStr[i] ^ this.enckey);
		}
		string finalString="";
		try{
			s=new String(temp);

		}
		catch (Exceptiton e){
			e.printStackTrace();
		}
		String reverse = new StringBuffer(s).reverse().toString();

    // check whether the string is palindrome or not
		if (s.equals(reverse))
			return 1;
      //System.out.println("Yes");

		else
			return 0;
      //System.out.println("No");

	}

	public static void main(String args[]) {
		
		Client c = new Client();

		c.json();
		c.protobuf();
	}
}