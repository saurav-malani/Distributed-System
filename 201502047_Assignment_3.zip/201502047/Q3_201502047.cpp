#include<iostream>
#include<algorithm>
#include<mpi.h>
#include <vector>
using namespace std;
typedef
struct input
{
	int start;
	int end;	
}vertex;

bool compare(const pair<int,vertex> &a, const pair<int, vertex> &b)
{
	return (a.first<b.first);
}
bool Check_disjointset(int i,int j, std::vector<int > mapping)
{
	
	while(mapping[i]!=-1)
	{
		i=mapping[i];
	}
	while(mapping[j]!=-1)
	{
		j=mapping[i];
	}
	if (i!=j)
	{
		mapping[i]=j;
		return true;
	}
	else
		return false;
}
// void addvertex(pair<int, vertex>edge[i].second.start,pair<int>)
// {
// 	mapping[i]=j;

// }
int main(int argc, char **argv)
{
	
	//sort(arr)
	MPI_Init(&argc,&argv);   //initilization of MPI
	int world_rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
	int world_size;
	MPI_Comm_size(MPI_COMM_WORLD, &world_size);
	if(world_rank==0)  //considering this to be master
	{
		int v, e;
		int i;
	//int arr[e][3];
		cin>>v>>e;
		pair<int, vertex> p;
		vector<pair<int,vertex> > edge;
		vertex vet_temp;
		int weight_temp; 
		for(i=0;i<e;i++)
		{
			cin>>vet_temp.start>>vet_temp.end>>p.first;
			p.second=vet_temp;

			edge.push_back(p);
		}
		int n=10;
		int arr[n];
		int array_size= n/(world_size-1);

		for(i=0;i<n;i++)
			arr[i]=i;
		for(int i=1;i<world_size;i++)
		{
			MPI_Send(&array_size,1, MPI_INT, i, 0, MPI_COMM_WORLD);

			int ind=((i-1)*(n))/(world_size-1);
			MPI_Send(&arr[ind],array_size, MPI_INT, i, 0, MPI_COMM_WORLD);
			
			//int ind=((i-1)*(n))/(world_size-1);
			//MPI_Send(&arr[ind],array_size, MPI_INT, i, 0, MPI_COMM_WORLD);
			// MPI_Recv(&myarr, (n/world_size-1), MPI_INT, 0, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		}
		sort(edge.begin(),edge.end(),compare);
	//cout<<"sorted array wrt weight of edge"<<endl;
	//for(i=0;i<e;i++)
	//	cout<<edge[i].first<<" "<<edge[i].second.start<<" "<<edge[i].second.end<<endl;

		std::vector<int> mapping(v+1);
		for(int j=0 ; j <  v+1; j++)
		{
			mapping[j]=-1;
		//cout << mapping[j];
		}
		std::vector<pair<int,vertex> > mst;
	//cout << "I " << i;

		for(i=0;i<e;i++)

		{

		//cout << "I " << i;
			if(Check_disjointset(edge[i].second.start,edge[i].second.end,mapping))
			{
				//addvertex(mapping,edge[i].second.start,edge[i].second.end[i])
				//cout<<'chutiya'<< edge[i].second.start;
				mst.push_back(edge[i]);
			}
		}
		for(int i=1;i<world_size;i++)
		{
			int ind=(i-1)*array_size;
			MPI_Recv(&arr[ind],array_size, MPI_INT, i, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			// MPI_Recv(&myarr, (n/world_size-1), MPI_INT, 0, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		}
		//cout<<"MST"<<endl;
		for(i=0;i<v-1;i++)
		{
			cout<<mst[i].second.start<<" "<<mst[i].second.end<<" "<<mst[i].first<<" "<<endl;
		}
	}
	else
	{
		int array_size;
		MPI_Recv(&array_size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		int array[array_size];
		MPI_Recv(&array, array_size, MPI_INT, 0, 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);



		sort(array,array+array_size);
		MPI_Send(&array, array_size, MPI_INT, 0, 0, MPI_COMM_WORLD);

	}

	MPI_Finalize();  
	return 0;

}